#!/bin/bash

set -e

source environment.sh
python3 application.py runserver
